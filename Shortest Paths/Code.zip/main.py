import json

# Import of search algorithms
from Dijkstra import Dijkstra
from Uniform import Uniform
from AStar import AStar

def main():
    i = 1
    G = jsonLoad('G.json', i)
    i = 2
    Dist = jsonLoad('Dist.json', i)
    i = 3
    Cost = jsonLoad('Cost.json', i)
    i = 4
    Coord = jsonLoad('Coord.json', i)

    startNode = "1"
    endNode = "50"
    energyBudget = 287932
    
    print("\n---------------------------Welcome to CZ3005 Assignment 1---------------------------------")
    print("Enter: 1 --- Using Dijkstra Algorithm")
    print("Enter: 2 --- Using Uniform Cost Search Algorithm")
    print("Enter: 3 --- Using A* Search Algorithm")
    print("Enter: 4 --- Exit System")
    user_input = input("Please select following options for further information or exit system:")
    input_number = int(user_input)
    

    while True:
        if input_number == 1:
            print("\n> TASK 1: Results of Dijkstra Greedy Algorithm")
            Dijkstra().dijkstraSearch(startNode,endNode,G, Dist)
            user_input = input("\n\nPlease select 1, 2, 3 or exit system:")
            input_number = int(user_input)

        elif input_number == 2:
            print("\n> TASK 2: Results of Uniform Cost Search")
            Uniform().uniformCostSearch(startNode, endNode, energyBudget, G, Cost, Dist)
            user_input = input("\n\nPlease select 1, 2, 3 or exit system:")
            input_number = int(user_input)

        elif input_number == 3:
            print("\n> TASK 3: Results of A* Search Algorithm")
            AStar().AStarSearch(startNode, endNode, energyBudget, G, Cost, Dist, Coord).outputResult()
            user_input = input("\n\nPlease select 1, 2, 3 or exit system:")
            input_number = int(user_input)

        else:
            break
        

def jsonLoad(file, i):
    tmp = open(file)
    data = json.load(tmp)
    tmp.close()
    print("File loading Procedure: " + str(25*i) + " %")
    return data

if __name__ == "__main__":
    main()
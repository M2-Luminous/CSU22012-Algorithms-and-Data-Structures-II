from queue import PriorityQueue
import math
import sys

class Dijkstra:
    visitedNodes = []           #visitedNodes = visitedV
    shortestDistance = []       #shortestDistance = shortestD
    previousNodes = []          #previousNodes = previousV
    shortestPath = ""           #shortestPath = ShortestPath

    def __init__(self):
        self.visitedNodes = []
        self.shortestDistance = []
        self.previousNodes = []
        self.shortestPath = ""

    def dijkstraSearch(self, startNode, endNode, G, Dist):
        startVertex = int(startNode)
        endVertex = int(endNode)

        vertexCount = len(G)    #vertexCount = numV
        shortestDistance = [sys.float_info.max] * (vertexCount + 1)
        previousNodes = [-1] * (vertexCount + 1)
        visitedNodes = [False] * (vertexCount + 1)

        shortestDistance[startVertex] = 0

        header = PriorityQueue()
        header.put((0, str(startVertex)))

        while not header.empty():
            currNode = header.get()
            visitedNodes[int(currNode[1])] = True

            for iteration in range(len(G[currNode[1]])):
                tmpVertex = G[currNode[1]][iteration]
                currCost = float(Dist[currNode[1] + "," + tmpVertex])
                if currCost > 0 and visitedNodes[int(tmpVertex)] == False and shortestDistance[int(tmpVertex)] > shortestDistance[int(currNode[1])] + currCost:
                    shortestDistance[int(tmpVertex)] = shortestDistance[int(currNode[1])] + currCost
                    previousNodes[int(tmpVertex)] = int(currNode[1])
                    header.put((shortestDistance[int(tmpVertex)], tmpVertex))

        resultString = endNode
        currNode = previousNodes[endVertex]
        while currNode != -1:
            resultString = str(currNode) + " -> " + resultString
            currNode = previousNodes[currNode]
        
        print("The shortest path using Dijkstra algorithm is: [" + resultString + "]")
        print("\nThe shortest distance using Dijkstra algorithm is:", shortestDistance[endVertex])
        print("The lowest energy cost using Dijkstra algorithm is: " + str(currCost))


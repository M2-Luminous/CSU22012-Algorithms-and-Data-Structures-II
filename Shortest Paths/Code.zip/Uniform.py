from queue import PriorityQueue
import math

class Uniform:                  #Uniform = UniformCostSearch
    visitedNodes = []         #visitedNodes = ExploredSet
    shortestDistance = []     #shortestDistance = TotalDistance
    lowestEnergy = []         #lowestEnergy = TotalEnergy
    shortestPath = ""           #shortestPath = ShortestPath

    def __init__(self):
        self.visitedNodes = []
        self.shortestDistance = []
        self.lowestEnergy = []
        self.shortestPath = ""

    def minimum_distance(self, parentNode, endNode):
        currNode = endNode
        shortestPath = []
        while currNode is not None:
            shortestPath.append(currNode)
            currNode = parentNode[currNode]
        print("The shortest path using ucs algorithm is: [" + " -> ".join(shortestPath) + "]" + "\n")

    #EnergyCap = energyBudget
    def uniformCostSearch(self, startNode, endNode, energyBudget, G, Cost, Dist):
        visitedNodes = set()
        shortestDistance = {startNode : 0}
        lowestCost = {startNode : 0}
        parentNode = {startNode : None}

        header = PriorityQueue()
        header.put((0, startNode))

        while not header.empty():
            (_, currNode) = header.get()

            if currNode in visitedNodes:
                continue
            else:
                visitedNodes.add(currNode)

            if currNode == endNode:
                break

            for adjacentNode in G.get(str(currNode)):
                minDistance = shortestDistance.get(adjacentNode, float('inf'))
                minCost = lowestCost.get(adjacentNode, float('inf'))

                currDistance = shortestDistance[currNode] + Dist[str(currNode) + "," + str(adjacentNode)]
                currCost = lowestCost[currNode] + Cost[str(currNode) + "," + str(adjacentNode)]

                if currDistance < minDistance and currCost < minCost and currCost < energyBudget:
                    header.put((currDistance, adjacentNode))
                    shortestDistance[adjacentNode] = currDistance
                    lowestCost[adjacentNode] = currCost
                    parentNode[adjacentNode] = currNode
        if endNode in parentNode.keys():
            self.minimum_distance(parentNode, endNode)
            print("The shortest distance using ucs algorithm is: " + str(shortestDistance[endNode]))
            print("The lowest energy cost using ucs algorithm is:" + str(lowestCost[endNode]))
        else:
            return None


from queue import PriorityQueue
import math

class AStar:                    #AStar = AStarSearch Algotithm
    visitedNodes = []         #visitedNodes = ExploredSet
    shortestDistance = []     #shortestDistance = TotalDistance
    lowestEnergy = []         #lowestEnergy = TotalEnergy
    shortestPath = ""           #shortestPath = ShortestPath

    def __init__(self):
        self.visitedNodes = []
        self.shortestDistance = []
        self.lowestEnergy = []
        self.shortestPath = ""

    def heuristic(self, tmpV1, tmpV2, coord):
        tmpCoord1 = coord[tmpV1]
        tmpCoord2 = coord[tmpV2]

        slope = pow(tmpCoord2[0] - tmpCoord1[0], 2) + pow(tmpCoord2[1] - tmpCoord1[1], 2)
        result = math.sqrt(slope)
        return result

    #EnergyCap = energyBudget
    def AStarSearch(self, startNode, endNode, energyBudget, G, Cost, Dist, Coord):
        visited = {}                            #visited = Explored
        distantCost = {}                        #distantCost = DistCost
        minCost = {}                            #minCost = minCost
        minDistance = {}                        #minDistance = minDist

        #initialize starting node
        visited[(startNode, 0)] = None
        distantCost[(startNode, 0)] = 0

        header = PriorityQueue()                #header = Frontier
        header.put((0, 0, (startNode, 0)))      #0 priority, 0 distance, startNode, 0 cost

        while not header.empty():               #currentNode = current
            currentPriority, currentDistance, (currentNode, currentCost) = header.get()     #the first vertex

            if currentNode in minDistance and currentNode in minCost and minDistance[currentNode] <= currentDistance and minCost[currentNode] <= currentCost:
                continue

            #optimise
            if currentNode not in minDistance:
                minDistance[currentNode] = currentDistance
            if minDistance[currentNode] > currentDistance:
                minDistance[currentNode] = currentDistance

            if currentNode not in minCost:
                minCost[currentNode] = currentCost
            if minCost[currentNode] > currentCost:
                minCost[currentNode] = currentCost

            if currentNode == endNode:
                break

            #havn't reach the end node, then keep explore
            adjacentNode = G[currentNode]                       #adjacentNode = neighbours
            for nextNode in adjacentNode:                       #nextNode = next
                dist = Dist[currentNode + "," + nextNode]    
                cost = Cost[currentNode + "," + nextNode]       #cost = energy
                newDist = currentDistance + dist
                newCost = currentCost + cost                    #newCost = newEnergy

                if(nextNode, newCost) not in visited and newCost <= energyBudget:
                    currentPriority = newDist + (self.heuristic(currentNode, nextNode, Coord))
                    # Insert the next node into the frontier, with its fCost as the exploration priority
                    header.put((currentPriority, newDist, (nextNode, newCost)))
                    # Store its costs
                    distantCost[(nextNode, newCost)] = newDist
                    # Update the exploration status and set the current node to be the exploration parent node
                    visited[(nextNode, newCost)] = (currentNode, currentCost)
        
        #store the calculated values back to init
        self.visitedNodes = visited
        self.shortestDistance = distantCost[endNode, minCost[endNode]]
        self.lowestEnergy = minCost[endNode]
        self.resultString(endNode, minCost[endNode], Dist, Cost)
        return self

    def resultString(self, endNode, minCost, Dist, Cost, status = False):           #status = check
        outputDist = 0                                                              #outputDist = tempD
        outputCost = 0                                                              #outputCost = tempC
        result = ""
        currentNode = self.visitedNodes[endNode, minCost]
        while currentNode != None:
            result = currentNode[0] + " -> " + result
            if self.visitedNodes[currentNode] != None and status == True:
                outputDist += Dist[self.visitedNodes[currentNode][0] + ',' + currentNode[0]]
                outputCost += Cost[self.visitedNodes[currentNode][0] + ',' + currentNode[0]]
            currentNode = self.visitedNodes[currentNode]
        self.shortestPath = result + endNode
        if status == True:
            outputDist += Dist[self.visitedNodes[endNode, minCost][0] + ',' + endNode]
            outputCost += Cost[self.visitedNodes[endNode, minCost][0] + ',' + endNode]
            print(outputDist)
            print(outputCost)
        return self

    def outputResult(self):
        print("The shortest path using A* algorithm is: [" + self.shortestPath + "]")
        print("\nThe shortest distance using A* algorithm is: " + str(self.shortestDistance))
        print("The lowest energy cost using A* algorithm is: " + str(self.lowestEnergy))
